﻿using Common.Enums;
using DataAccess.Entities;
using MongoDB.Bson;
using MongoDB.Driver;

namespace DataAccess.Services;

public class QuizRepository
{
    private IMongoCollection<Question> questionsCollection;
    private IMongoCollection<Quiz> quizCollection;


    public QuizRepository()
    {
        var hostName = "localhost";
        var port = "27017";
        var databaseName = "QuizesBank";
        var client = new MongoClient($"mongodb://{hostName}:{port}");
        var database = client.GetDatabase(databaseName);
        questionsCollection =
            database.GetCollection<Question>("questions", new MongoCollectionSettings() { AssignIdOnInsert = true });
        quizCollection =
            database.GetCollection<Quiz>("Quiz", new MongoCollectionSettings() { AssignIdOnInsert = true });

    }

    public void QuizMenu()
    {

        while (true)
        {

            Console.WriteLine("Choose an option:");
            Console.WriteLine("1. List questions for a quiz");
            Console.WriteLine("2. Add question to a quiz");
            Console.WriteLine("3. Remove question from a quiz");
            Console.WriteLine("4. Create a new quiz");
            Console.WriteLine("5. List questions by category");
            Console.WriteLine("6. Delete a question");
            Console.WriteLine("7. Update a question");
            Console.WriteLine("8. Delete a quiz");
            Console.WriteLine("9. Update a quiz");
            Console.WriteLine("10. Exit");


            Console.Write("Enter your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ListQuestionsForQuiz();
                    break;
                case "2":
                    AddQuestionToQuiz();
                    break;
                case "3":
                    RemoveQuestionFromQuiz();
                    break;
                case "4":
                    CreateNewQuiz();
                    break;
                case "5":
                    ListQuestionsByCategory();
                    break;
                case "6":
                    DeleteQuestion();
                    break;
                case "7":
                    UpdateQuestion();
                    break;
                case "8":
                    DeleteQuiz();
                    break;
                case "9":
                    UpdateQuiz();
                    break;
                case "10":
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }
    }


    private void ListQuestionsForQuiz()
    {
        Console.WriteLine("Available Quizzes:");
        var allQuizzes = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();
        for (int i = 0; i < allQuizzes.Count; i++)
        {
            Console.WriteLine(
                $"{i + 1}. Id: {allQuizzes[i].Id}, Title: {allQuizzes[i].Title}, Description: {allQuizzes[i].Description}");
        }

        Console.Write("Enter the number of the quiz to view its questions: ");
        int selectedQuizIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuizIndex) || selectedQuizIndex < 1 ||
            selectedQuizIndex > allQuizzes.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuiz = allQuizzes[selectedQuizIndex - 1];

        Console.WriteLine($"Questions for the Quiz '{selectedQuiz.Title}':\n");
        foreach (var questionId in selectedQuiz.QuestionIds)
        {
            var filter = Builders<Question>.Filter.Eq(q => q.Id, questionId);
            var question = questionsCollection.Find(filter).SingleOrDefault();
            if (question != null)
            {
                Console.WriteLine($"Id: {question.Id}");
                Console.WriteLine($"QuestionText: {question.QuestionText}");
                Console.WriteLine($"Options: {string.Join(", ", question.Options)}");
                Console.WriteLine($"CorrectAnswer: {question.CorrectAnswer}");
                Console.WriteLine("Categories:");
                foreach (var category in question.Categories)
                {
                    Console.WriteLine($"- {category}");
                }
                Console.WriteLine("---------------------------------");
            }
        }
    }

    private void AddQuestionToQuiz()
    {
        Console.Write("Enter the question text: ");
        string text = Console.ReadLine();

        List<string> options = new List<string>();
        for (int i = 1; i <= 3; i++)
        {
            Console.Write($"Enter option {i}: ");
            options.Add(Console.ReadLine());
        }

        Console.Write("Enter the correct answer: ");
        string correctAnswer = Console.ReadLine();

        Console.WriteLine("Select the category:");
        foreach (Category category in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine($"{(int)category}. {category}");
        }

        Console.Write("Enter the category number: ");
        int categoryNumber = Convert.ToInt32(Console.ReadLine());
        Category selectedCategory = (Category)categoryNumber;

        Question question = new Question
        {
            QuestionText = text,
            Options = options,
            CorrectAnswer = correctAnswer,
            Categories = new List<Category> { selectedCategory }
        };

        questionsCollection.InsertOne(question);
        Console.WriteLine("Question added successfully.");


        Console.WriteLine("Available Questions:");
        var allQuestions = questionsCollection.Find(Builders<Question>.Filter.Empty).ToList();
        for (int i = 0; i < allQuestions.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Question: {allQuestions[i].QuestionText}");
        }

        Console.Write("Enter the number of the question to add to the quiz: ");
        int selectedQuestionIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuestionIndex) || selectedQuestionIndex < 1 || selectedQuestionIndex > allQuestions.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }
        var selectedQuestion = allQuestions[selectedQuestionIndex - 1];


        Console.WriteLine("\nAvailable Quizzes:");
        var allQuizzes = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();
        for (int i = 0; i < allQuizzes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Quiz: {allQuizzes[i].Title}");
        }

        Console.Write("Enter the number of the quiz to which you want to add the question: ");
        int selectedQuizIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuizIndex) || selectedQuizIndex < 1 || selectedQuizIndex > allQuizzes.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuiz = allQuizzes[selectedQuizIndex - 1];

        if (selectedQuiz.QuestionIds.Contains(selectedQuestion.Id))
        {
            Console.WriteLine("Question already exists in the quiz!");
            return;
        }

        selectedQuiz.QuestionIds.Add(selectedQuestion.Id);
        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, selectedQuiz.Id);
        var update = Builders<Quiz>.Update.Set(q => q.QuestionIds, selectedQuiz.QuestionIds);
        quizCollection.UpdateOne(filter, update);

        Console.WriteLine("Question added to the quiz successfully!");
    }


    private void RemoveQuestionFromQuiz()
    {
        Console.WriteLine("Available Quizzes:");
        var allQuizzes = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();
        for (int i = 0; i < allQuizzes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Title: {allQuizzes[i].Title}");
        }

        Console.Write("Enter the number of the quiz to remove a question from: ");
        int selectedQuizIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuizIndex) || selectedQuizIndex < 1 || selectedQuizIndex > allQuizzes.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuiz = allQuizzes[selectedQuizIndex - 1];


        Console.WriteLine($"\nQuestions for the quiz '{selectedQuiz.Title}':");
        var quizQuestions = questionsCollection.Find(Builders<Question>.Filter.In(q => q.Id, selectedQuiz.QuestionIds)).ToList();
        for (int i = 0; i < quizQuestions.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Question: {quizQuestions[i].QuestionText}");
        }

        Console.Write("Enter the number of the question to remove from the quiz: ");
        int selectedQuestionIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuestionIndex) || selectedQuestionIndex < 1 || selectedQuestionIndex > quizQuestions.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuestion = quizQuestions[selectedQuestionIndex - 1];

        if (!selectedQuiz.QuestionIds.Contains(selectedQuestion.Id))
        {
            Console.WriteLine("Question does not exist in the quiz!");
            return;
        }

        selectedQuiz.QuestionIds.Remove(selectedQuestion.Id);
        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, selectedQuiz.Id);
        var update = Builders<Quiz>.Update.Set(q => q.QuestionIds, selectedQuiz.QuestionIds);
        quizCollection.UpdateOne(filter, update);

        Console.WriteLine("Question removed from the quiz successfully!");

    }

    private void CreateNewQuiz()
    {
        Console.Write("Enter the quiz name: ");
        string quizName = Console.ReadLine();

        Console.Write("Enter the quiz description: ");
        string quizDescription = Console.ReadLine();

        var newQuiz = new Quiz
        {
            Title = quizName,
            Description = quizDescription,
            QuestionIds = new List<ObjectId>(),

        };

        quizCollection.InsertOne(newQuiz);

        Console.WriteLine("New quiz created successfully!");
    }

    private void ListQuestionsByCategory()
    {
        foreach (Category enumDisplay in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine(enumDisplay);
        }


        Console.Write("Enter the category name: ");
        string categoryName = Console.ReadLine();

        if (string.IsNullOrEmpty(categoryName))
        {
            Console.WriteLine("Category name cannot be empty.");
            return;
        }

        if (!Enum.TryParse(typeof(Category), categoryName, true, out var categoryEnum))
        {
            Console.WriteLine("Invalid category name.");
            return;
        }

        var category = (Category)categoryEnum;

        var filter = Builders<Question>.Filter.Where(q => q.Categories.Contains(category));
        var questionsInCategory = questionsCollection.Find(filter).ToList();

        if (questionsInCategory.Count == 0)
        {
            Console.WriteLine("No questions found in the specified category.");
            return;
        }

        Console.WriteLine($"Questions in category '{categoryName}':");
        foreach (var question in questionsInCategory)
        {
            Console.WriteLine($"- {question.QuestionText}");
        }
    }

    private void DeleteQuestion()
    {
        Console.WriteLine("Available Questions:");
        var allQuestions = questionsCollection.Find(Builders<Question>.Filter.Empty).ToList();
        for (int i = 0; i < allQuestions.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Question: {allQuestions[i].QuestionText}");
        }

        Console.Write("Enter the number of the question to delete: ");
        int selectedQuestionIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuestionIndex) || selectedQuestionIndex < 1 || selectedQuestionIndex > allQuestions.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuestion = allQuestions[selectedQuestionIndex - 1];

        Console.WriteLine($"\nAre you sure you want to delete the question: '{selectedQuestion.QuestionText}'? (yes/no)");
        string confirmation = Console.ReadLine().ToLower();
        if (confirmation != "yes")
        {
            Console.WriteLine("Deletion cancelled.");
            return;
        }

        var filter = Builders<Question>.Filter.Eq(q => q.Id, selectedQuestion.Id);
        questionsCollection.DeleteOne(filter);

        Console.WriteLine("Question deleted successfully!");

    }

    private void UpdateQuestion()
    {
        Console.WriteLine("Available Questions:");
        var allQuestions = questionsCollection.Find(Builders<Question>.Filter.Empty).ToList();
        for (int i = 0; i < allQuestions.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Question: {allQuestions[i].QuestionText}");
        }

        Console.Write("Enter the number of the question to update: ");
        int selectedQuestionIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuestionIndex) || selectedQuestionIndex < 1 || selectedQuestionIndex > allQuestions.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }
        var selectedQuestion = allQuestions[selectedQuestionIndex - 1];

        Console.Write("Enter the new question text: ");
        string newQuestionText = Console.ReadLine();

        List<string> options = new List<string>();
        for (int i = 1; i <= 3; i++)
        {
            Console.Write($"Enter updated option {i}: ");
            options.Add(Console.ReadLine());
        }

        Console.Write("Enter the new correct answer: ");
        string newCorrectAnswer = Console.ReadLine();

        Console.WriteLine("Select the updated category:");
        foreach (Category category in Enum.GetValues(typeof(Category)))
        {
            Console.WriteLine($"{(int)category}. {category}");
        }
        Console.Write("Enter the updated category number: ");
        int categoryNumber = Convert.ToInt32(Console.ReadLine());
        Category selectedCategory = (Category)categoryNumber;

        var filter = Builders<Question>.Filter.Eq(q => q.Id, selectedQuestion.Id);
        var update = Builders<Question>.Update
            .Set(q => q.QuestionText, newQuestionText)
            .Set(q => q.Options, options)
            .Set(q => q.CorrectAnswer, newCorrectAnswer)
            .Set(q => q.Categories, new List<Category> { selectedCategory });
        questionsCollection.UpdateOne(filter, update);

        Console.WriteLine("Question updated successfully!");

    }

    private void DeleteQuiz()
    {
        Console.WriteLine("Available Quizes:");
        var allQuizes = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();
        for (int i = 0; i < allQuizes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Quiz: {allQuizes[i].Title}");
        }

        Console.Write("Enter the number of the quiz to delete: ");
        int selectedQuizIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuizIndex) || selectedQuizIndex < 1 || selectedQuizIndex > allQuizes.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuiz = allQuizes[selectedQuizIndex - 1];


        Console.WriteLine($"\nAre you sure you want to delete the question: '{selectedQuiz.Title}'? (yes/no)");
        string confirmation = Console.ReadLine().ToLower();
        if (confirmation != "yes")
        {
            Console.WriteLine("Deletion cancelled.");
            return;
        }


        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, selectedQuiz.Id);
        quizCollection.DeleteOne(filter);

        Console.WriteLine("Quiz deleted successfully!");

    }

    private void UpdateQuiz()
    {
        Console.WriteLine("Available Quizes:");
        var allQuizes = quizCollection.Find(Builders<Quiz>.Filter.Empty).ToList();
        for (int i = 0; i < allQuizes.Count; i++)
        {
            Console.WriteLine($"{i + 1}. Quiz: {allQuizes[i].Title}");
        }

        Console.Write("Enter the number of the quiz to update: ");
        int selectedQuizIndex;
        if (!int.TryParse(Console.ReadLine(), out selectedQuizIndex) || selectedQuizIndex < 1 || selectedQuizIndex > allQuizes.Count)
        {
            Console.WriteLine("Invalid input! Please enter a valid number.");
            return;
        }

        var selectedQuiz = allQuizes[selectedQuizIndex - 1];

        Console.Write("Enter the new title for the quiz: ");
        string newTitle = Console.ReadLine();

        Console.Write("Enter the new description for the quiz: ");
        string newDescription = Console.ReadLine();


        var filter = Builders<Quiz>.Filter.Eq(q => q.Id, selectedQuiz.Id);
        var update = Builders<Quiz>.Update
            .Set(q => q.Title, newTitle)
            .Set(q => q.Description, newDescription);

        quizCollection.UpdateOne(filter, update);

        Console.WriteLine("Quiz updated successfully!");


    }
}
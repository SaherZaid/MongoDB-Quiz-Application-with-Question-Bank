﻿using MongoDB.Bson;

namespace DataAccess.Entities;

public class Quiz
{
    public ObjectId Id { get; set; }
    public string Title { get; set; }
    public string Description { get; set; }
    public List<ObjectId> QuestionIds { get; set; }

}
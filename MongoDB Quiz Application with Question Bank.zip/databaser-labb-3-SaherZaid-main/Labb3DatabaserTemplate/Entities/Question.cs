﻿using Common.Enums;
using MongoDB.Bson;

namespace DataAccess.Entities;

public class Question
{ 
    public ObjectId Id { get; set; }
    public string QuestionText { get; set; }
    public List<string> Options { get; set; }
    public string CorrectAnswer { get; set; }
    public List<Category> Categories { get; set; }
}
﻿namespace Common.Enums;

public enum Category
{
    History,
    Science,
    Math,
    Sport,
    Geography
}
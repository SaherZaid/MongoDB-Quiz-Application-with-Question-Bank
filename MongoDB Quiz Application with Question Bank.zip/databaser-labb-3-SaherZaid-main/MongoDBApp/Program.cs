﻿using DataAccess.Services;

QuizRepository quiz = new QuizRepository();
quiz.QuizMenu();